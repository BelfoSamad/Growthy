export interface Test {
  name?: string;
}
