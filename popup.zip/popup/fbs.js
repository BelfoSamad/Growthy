/*
<!-- The core Firebase JS SDK is always required and must be listed first -->
*/
<script src="https://www.gstatic.com/firebasejs/7.15.5/firebase-app.js"></script>

/*
<!-- TODO: Add SDKs for Firebase products that you want to use
     https://firebase.google.com/docs/web/setup#available-libraries -->
*/
<script src="https://www.gstatic.com/firebasejs/7.15.5/firebase-analytics.js"></script>

<script>
  // Your web app's Firebase configuration
  var firebaseConfig = {
    apiKey: "AIzaSyD29SsoqMAJlpezphsMnNd6-EVmXXRBS_U",
    authDomain: "ext-ng.firebaseapp.com",
    databaseURL: "https://ext-ng.firebaseio.com",
    projectId: "ext-ng",
    storageBucket: "ext-ng.appspot.com",
    messagingSenderId: "367815588601",
    appId: "1:367815588601:web:47b22df35fca571ad0c028",
    measurementId: "G-6N4H4VDGCS"
  };
  // Initialize Firebase
  firebase.initializeApp(firebaseConfig);
  firebase.analytics();
</script>
